'use strict';
/**
 * Academic Research Explorer — full-stack server.
 * No npm dependencies: Node.js built-ins only (Node 18+).
 *
 *   node server.js                       -> http://localhost:3000
 *   PORT=8080 DATA_FILE=... DATA_DIR=... node server.js
 *
 * Judgments are stored in DATA_DIR/judgments.json (default: ./data).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { loadDataset } = require('./lib/data');
const { prepare, search, selectHits, relevance } = require('./lib/search');
const { computeStats, facets } = require('./lib/stats');
const { parseFilter, passes } = require('./lib/filters');
const { queryStats } = require('./lib/query');
const { buildGraph, graphStats } = require('./lib/graph');
const { rankFor, queryMetrics, prCurve, rocAuc, heuristicGrade, cohenKappa, norm } = require('./lib/evaluate');
const { JudgmentStore } = require('./lib/store');
const { splitList } = require('./lib/text');

const PUBLIC_DIR = path.join(__dirname, 'public');
const DEFAULT_DATA = path.join(__dirname, 'data', 'dataset.json');
const SORTS = ['relevance', 'cites', 'newest', 'oldest', 'title'];
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
};
const MAX_BODY = 64 * 1024;

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function loadStore(opts) {
  const t0 = Date.now();
  const records = prepare(loadDataset(opts.dataFile));
  const years = records.map((r) => r.year).filter((y) => y > 0);
  const dataDir = opts.dataDir || path.dirname(opts.dataFile);
  return {
    records,
    loadMs: Date.now() - t0,
    datasetName: path.basename(opts.dataFile),
    judgments: new JudgmentStore(opts.judgmentsFile || path.join(dataDir, 'judgments.json')),
    dashCache: new Map(),
    meta: {
      recordCount: records.length,
      minYear: years.length ? Math.min(...years) : 0,
      maxYear: years.length ? Math.max(...years) : 0,
      maxCites: records.reduce((a, r) => Math.max(a, r.cites), 0),
      facets: facets(records),
    },
  };
}

const num = (v) => {
  if (v === null || v === undefined || v === '') return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
};
const clamp = (v, lo, hi, d) => (v === undefined ? d : Math.min(hi, Math.max(lo, Math.floor(v))));

function parseSearch(sp) {
  const sort = sp.get('sort') || 'relevance';
  return {
    q: (sp.get('q') || '').slice(0, 500),
    sort: SORTS.includes(sort) ? sort : 'relevance',
    page: Math.max(1, Math.floor(num(sp.get('page')) || 1)),
    pageSize: clamp(num(sp.get('pageSize')), 1, 100, 20),
    yearFrom: num(sp.get('yearFrom')),
    yearTo: num(sp.get('yearTo')),
    years: new Set((sp.get('years') || '').split(',').map(Number).filter((n) => Number.isFinite(n) && n > 0)),
    source: sp.get('source') || '',
    publisher: sp.get('publisher') || '',
    country: sp.get('country') || '',
    keyword: (sp.get('keyword') || '').slice(0, 200),
    hasLink: ['true', '1'].includes(sp.get('hasLink')),
    minCites: Math.max(0, num(sp.get('minCites')) || 0),
  };
}

/** Dashboard parameters: scope, year range, field filters, display limits. */
function parseDash(sp) {
  const filters = sp.getAll('filter').map(parseFilter).filter(Boolean);
  return {
    q: (sp.get('q') || '').trim().slice(0, 500),
    scope: sp.get('scope') === 'results' ? 'results' : 'all',
    from: num(sp.get('from')),
    to: num(sp.get('to')),
    filters,
    topN: clamp(num(sp.get('topN')), 1, 50, 10),
    minKw: clamp(num(sp.get('minKw')), 1, 50, 3),
    limit: clamp(num(sp.get('limit')), 1, 100, 20),
  };
}

function provenance(store, p, extra = {}) {
  return {
    dataset: { file: store.datasetName, records: store.records.length },
    scope: p.scope,
    query: p.q || null,
    yearFrom: p.from ?? null,
    yearTo: p.to ?? null,
    filters: p.filters.map((f) => ({ field: f.field, value: f.value })),
    generated: new Date().toISOString(),
    ...extra,
  };
}

/** Records in the dashboard base: whole collection or current search results, then filters. */
function dashBase(store, p) {
  const pool = p.scope === 'results'
    ? selectHits(store.records, { q: p.q, sort: 'relevance', years: new Set() }).map((h) => h.rec)
    : store.records;
  return pool.filter((r) => passes(r, p));
}
/** Ranked matches of the query after the year range and filters. */
function queryHits(store, p) {
  return selectHits(store.records, { q: p.q, sort: 'relevance', years: new Set() }).filter((h) => passes(h.rec, p));
}

function csvCell(v) {
  let s = v === null || v === undefined ? '' : String(v);
  if (/^[=+\-@]/.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
function sendFile(res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return sendJson(res, 404, { error: 'Not found' });
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    fs.createReadStream(file).pipe(res);
  });
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => {
      d += c;
      if (d.length > MAX_BODY) { reject(new HttpError(413, 'Request body too large')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(d ? JSON.parse(d) : {}); }
      catch { reject(new HttpError(400, 'Invalid JSON body')); }
    });
    req.on('error', reject);
  });
}
const requireQuery = (p) => { if (!p.q) throw new HttpError(400, 'Parameter q (a search query) is required'); };

async function route(req, res, store) {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  const sp = url.searchParams;
  const isGet = req.method === 'GET' || req.method === 'HEAD';

  if (p === '/api/health' && isGet) return sendJson(res, 200, { ok: true, records: store.records.length, loadMs: store.loadMs });
  if (p === '/api/meta' && isGet) return sendJson(res, 200, store.meta);
  if (p === '/api/search' && isGet) return sendJson(res, 200, search(store.records, parseSearch(sp)));

  const rec = p.match(/^\/api\/records\/(\d+)$/);
  if (rec && isGet) {
    const r = store.records[Number(rec[1])];
    if (!r) throw new HttpError(404, 'Record not found');
    const { n, ...plain } = r; // eslint-disable-line no-unused-vars
    return sendJson(res, 200, { ...plain, keywordList: splitList(r.keywords) });
  }

  if (p === '/api/dashboard/overview' && isGet) {
    const d = parseDash(sp);
    const base = dashBase(store, d);
    return sendJson(res, 200, { provenance: provenance(store, d, { recordsInBase: base.length }),
      stats: computeStats(base, { topN: d.topN }) });
  }
  if (p === '/api/dashboard/query' && isGet) {
    const d = parseDash(sp);
    requireQuery(d);
    const hits = queryHits(store, d);
    return sendJson(res, 200, { provenance: provenance(store, d, { recordsInBase: hits.length }),
      query: queryStats(store.records, hits, d.q, { minKw: d.minKw, topN: d.topN }) });
  }
  if (p === '/api/dashboard/graph' && isGet) {
    const d = parseDash(sp);
    requireQuery(d);
    const hits = queryHits(store, d);
    const g = buildGraph(hits, { limit: d.limit });
    return sendJson(res, 200, { provenance: provenance(store, d, { recordsInBase: hits.length, recordsUsed: g.recordsUsed }),
      graph: graphStats(g) });
  }
  if (p === '/api/export/summary' && isGet) {
    const d = parseDash(sp);
    const base = dashBase(store, d);
    const out = { provenance: provenance(store, d, { recordsInBase: base.length }),
      overview: computeStats(base, { topN: d.topN }) };
    if (d.q) {
      const hits = queryHits(store, d);
      out.queryExplorer = queryStats(store.records, hits, d.q, { minKw: d.minKw, topN: d.topN });
      out.knowledgeGraph = graphStats(buildGraph(hits, { limit: d.limit }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="dashboard-summary.json"' });
    return res.end(JSON.stringify(out, null, 2));
  }
  if (p === '/api/export.csv' && isGet) {
    const hits = selectHits(store.records, parseSearch(sp)).slice(0, 5000);
    const cols = ['id', 'title', 'authors', 'year', 'source', 'publisher', 'country', 'cites', 'doi', 'url', 'keywords'];
    const lines = [cols.join(',')].concat(hits.map(({ rec }) => cols.map((c) => csvCell(rec[c])).join(',')));
    res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="search-results.csv"' });
    return res.end('\ufeff' + lines.join('\r\n'));
  }

  // ----- relevance judgments and evaluation -----
  if (p === '/api/judgments' && req.method === 'GET') {
    const q = (sp.get('q') || '').trim();
    if (!q) return sendJson(res, 200, { all: store.judgments.all() });
    return sendJson(res, 200, { q, grades: store.judgments.get(q) });
  }
  if (p === '/api/judgments' && req.method === 'POST') {
    const b = await readBody(req);
    const q = String(b.q || '').trim().slice(0, 500);
    const id = Number(b.id);
    const grade = b.grade === null ? null : Number(b.grade);
    if (!q) throw new HttpError(400, 'q is required');
    if (!Number.isInteger(id) || id < 0 || id >= store.records.length) throw new HttpError(400, 'id must be a record index');
    if (grade !== null && ![0, 1, 2].includes(grade)) throw new HttpError(400, 'grade must be 0, 1, 2 or null');
    store.judgments.set(q, id, grade);
    return sendJson(res, 200, { q, grades: store.judgments.get(q) });
  }
  if (p === '/api/evaluate/batch' && isGet) {
    const all = store.judgments.all();
    const rows = Object.keys(all).filter((q) => Object.keys(all[q]).length).map((q) => ({
      query: q, ...queryMetrics(rankFor(store.records, q), all[q]),
    }));
    const mean = (k) => {
      const v = rows.map((r) => r[k]).filter((x) => x !== null);
      return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
    };
    return sendJson(res, 200, {
      note: 'Ranking uses the default relevance order with no facet filters. Unjudged results count as not relevant.',
      queries: rows,
      macro: { precisionAt10: mean('precisionAt10'), recallAt10: mean('recallAt10'), ndcgAt10: mean('ndcgAt10'), averagePrecision: mean('averagePrecision') },
    });
  }
  if (p === '/api/evaluate/curve' && isGet) {
    const q = (sp.get('q') || '').trim();
    requireQuery({ q });
    const J = store.judgments.get(q);
    const ranking = rankFor(store.records, q);
    const curve = prCurve(ranking, J, 50);
    const pos = [], neg = [];
    for (const [i, g] of Object.entries(J)) {
      const score = relevance(store.records[Number(i)], q).score;
      (Number(g) > 0 ? pos : neg).push(score);
    }
    return sendJson(res, 200, { q, ...curve, rocAuc: rocAuc(pos, neg), relevantNonRelevant: { relevant: pos.length, nonRelevant: neg.length } });
  }
  if (p === '/api/evaluate/heuristic' && isGet) {
    const q = (sp.get('q') || '').trim();
    requireQuery({ q });
    const depth = clamp(num(sp.get('depth')), 1, 50, 20);
    const ranking = rankFor(store.records, q).slice(0, depth);
    const J = store.judgments.get(q);
    const rows = ranking.map((x, k) => {
      const g = heuristicGrade(store.records[x.i], q);
      return { rank: k + 1, id: x.i, title: store.records[x.i].title, auto: g.g, reason: g.why,
        human: Object.prototype.hasOwnProperty.call(J, x.i) ? Number(J[x.i]) : null };
    });
    const pairs = rows.filter((r) => r.human !== null).map((r) => [r.auto, r.human]);
    return sendJson(res, 200, { q, depth, rows, agreement: cohenKappa(pairs) });
  }
  if (p === '/api/evaluate/heuristic/accept' && req.method === 'POST') {
    const b = await readBody(req);
    const q = String(b.q || '').trim();
    requireQuery({ q });
    const depth = clamp(Number(b.depth), 1, 50, 20);
    const J = store.judgments.get(q);
    let added = 0;
    for (const x of rankFor(store.records, q).slice(0, depth)) {
      if (Object.prototype.hasOwnProperty.call(J, x.i)) continue;
      store.judgments.set(q, x.i, heuristicGrade(store.records[x.i], q).g);
      added++;
    }
    return sendJson(res, 200, { q, added, grades: store.judgments.get(q) });
  }

  if (p.startsWith('/api/')) {
    if (!isGet && req.method !== 'POST') throw new HttpError(405, 'Method not allowed');
    throw new HttpError(404, 'Unknown endpoint');
  }

  if (p === '/' && isGet) return sendFile(res, path.join(PUBLIC_DIR, 'index.html'));
  if (!isGet) throw new HttpError(405, 'Method not allowed');
  const file = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(p)));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) throw new HttpError(403, 'Forbidden');
  return sendFile(res, file);
}

function createServer(options = {}) {
  const store = loadStore({
    dataFile: options.dataFile || process.env.DATA_FILE || DEFAULT_DATA,
    dataDir: options.dataDir || process.env.DATA_DIR,
    judgmentsFile: options.judgmentsFile || process.env.JUDGMENTS_FILE,
  });
  return http.createServer((req, res) => {
    // Read-only data plus judgments; allow browsers to call the API from any origin (including file://).
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Max-Age', '600');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    route(req, res, store).catch((err) => {
      if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message });
      if (err instanceof URIError) return sendJson(res, 400, { error: 'Malformed URL' });
      console.error(err);
      if (!res.headersSent) sendJson(res, 500, { error: 'Internal server error' });
    });
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  createServer().listen(port, () => console.log(`Academic Research Explorer running at http://localhost:${port}`));
}

module.exports = { createServer, parseDash, parseSearch };
