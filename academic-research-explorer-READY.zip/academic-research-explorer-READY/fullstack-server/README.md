# Academic Research Explorer — full-stack edition (v3)

Bibliographic search, a dashboard with provenance, a query explorer, a knowledge graph of
search matches, and an evaluation lab (relevance judgments, precision/recall, nDCG, average
precision, precision–recall curves, ROC-AUC and heuristic grading with agreement).

No npm dependencies. Runs on Node.js 18 or later using only built-in modules.

## Quick start

```bash
npm start                                  # http://localhost:3000
PORT=8080 npm start                        # another port
npm test                                   # API tests (+ browser test if Playwright is installed)
```

Environment variables:

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `DATA_FILE` | `data/dataset.json` | dataset in the format below |
| `DATA_DIR` | folder of `DATA_FILE` | where `judgments.json` is kept |
| `JUDGMENTS_FILE` | `DATA_DIR/judgments.json` | explicit judgments file |

Docker:

```bash
docker build -t research-explorer .
docker run -p 3000:3000 -v "$PWD/store:/app/data" research-explorer
```

The volume keeps `judgments.json` between container restarts.

## Layout

```
server.js               HTTP server, routing, validation, static files, JSON errors
lib/data.js             loads the dataset and resolves lookup indices to names
lib/text.js             normalisation, tokens, phrases, list splitting
lib/search.js           field-weighted relevance, facet filters, sorting, paging
lib/filters.js          dashboard filters (year range, journal, publisher, country, year, keyword, author)
lib/stats.js            overview statistics; missing values counted separately
lib/query.js            query explorer: term coverage, enrichment, related keywords (lift), fields, bands
lib/graph.js            knowledge graph of top matches, graph statistics, hub edges
lib/evaluate.js         ranking, precision/recall/nDCG/AP, PR curve, ROC-AUC, heuristic grades, kappa
lib/store.js            judgments store (JSON, atomic writes)
public/index.html       single-page app: Search, Dashboard, Evaluate
data/dataset.json       bibliographic dataset (27,825 records)
test/api.test.js        API and calculation tests (26)
test/browser.e2e.js     optional browser test (Playwright)
```

## Dataset format

```json
{ "m": { "sources": [], "publishers": [], "places": [], "countries": [] },
  "r": [[cites, "Authors; separated", "Title", year, sourceIdx, publisherIdx, placeIdx, countryIdx,
         "url", "doi", "issn", "Keyword; list", "Abstract"], ...] }
```

## API

### Search and records

| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | record count and load time |
| GET | `/api/meta` | record count, year range, facet lists with counts |
| GET | `/api/search` | ranked, paged search. Parameters: `q`, `sort` (`relevance`, `cites`, `newest`, `oldest`, `title`), `page`, `pageSize` (1–100), `yearFrom`, `yearTo`, `years`, `source`, `publisher`, `country`, `keyword`, `hasLink`, `minCites` |
| GET | `/api/records/:id` | full record with keyword list |
| GET | `/api/export.csv` | search results as CSV (up to 5,000 rows, formula-safe) |

### Dashboard (same parameters on each endpoint)

Common parameters: `q` (query), `scope` (`all` or `results`), `from`, `to` (year range),
`filter` (repeatable, `field:value` with field one of `journal`, `publisher`, `country`,
`year`, `keyword`, `author`), `topN` (1–50), `minKw` (1–50, related-keyword threshold),
`limit` (1–100, records used for the graph).

| Method | Path | Returns |
|---|---|---|
| GET | `/api/dashboard/overview` | overview statistics for the base, with provenance |
| GET | `/api/dashboard/query?q=` | query explorer: matches, term coverage, enrichment, related keywords, fields, bands |
| GET | `/api/dashboard/graph?q=` | knowledge graph statistics for the top `limit` matches |
| GET | `/api/export/summary` | JSON bundle: provenance, overview, and (if `q`) query explorer and graph |

Errors are JSON: `{ "error": "…" }` with status 400, 404, 405, 413 or 500.

### Evaluation

| Method | Path | Notes |
|---|---|---|
| GET | `/api/judgments?q=` | grades for a query (`{ "recordIndex": grade }`); without `q`, all queries |
| POST | `/api/judgments` | body `{ "q", "id", "grade" }`; grade 0, 1, 2, or `null` to clear |
| GET | `/api/evaluate/batch` | P@10, R@10, nDCG@10, AP per judged query, with macro averages |
| GET | `/api/evaluate/curve?q=` | precision and recall at each of the top 50 ranks, average precision, ROC-AUC |
| GET | `/api/evaluate/heuristic?q=&depth=` | automatic grades, human grades, agreement and Cohen's κ |
| POST | `/api/evaluate/heuristic/accept` | body `{ "q", "depth" }`; saves suggestions for unjudged results only |

## Method and definitions

- **Counts** include a record only when the field has a value. Missing values are reported separately.
- **Keywords and authors** are grouped case- and accent-insensitively. The most frequent spelling is shown.
- **Share** = records in a row ÷ records in the base.
- **Term matching** is a substring test on normalised text, the same rule search scoring uses.
- **Coverage** = matches containing a term ÷ matches. **Collection share** = collection records containing it ÷ all records. **Enrichment** = coverage ÷ collection share.
- **Related keyword lift** = share of matches with the keyword ÷ share of the collection with it.
- **Graph density** = 2E ÷ (N(N−1)). Components are groups connected through links. The graph uses the top-ranked matches only.
- **Precision@k** = relevant in top k ÷ k. **Recall@k** = relevant in top k ÷ all relevant judged for the query. **nDCG@10** uses graded gains. **Average precision** sums precision at each relevant rank and divides by the relevant judged.
- **ROC-AUC** = probability that a relevant record scores above a non-relevant one (ties count half).
- **Cohen's κ** over the three grades: (p_o − p_e) ÷ (1 − p_e).
- **Ranking for evaluation** uses the default relevance order without facet filters. Unjudged results count as not relevant.

## Scope and limitations

- The server implements the **bibliographic** knowledge-graph schema. The standalone HTML application also offers five other schemas.
- Judgments are stored in a single JSON file. The store is suited to one user or a small team; writes are atomic, but concurrent writers can overwrite each other (last write wins).
- There is no authentication. Run it on a trusted network, or put it behind a proxy that adds authentication.
- The whole dataset is loaded into memory at start-up.
