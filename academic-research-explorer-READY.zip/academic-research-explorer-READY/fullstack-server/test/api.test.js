'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createServer } = require('../server');
const { norm } = require('../lib/text');
const { queryMetrics, prCurve, rocAuc, heuristicGrade, cohenKappa } = require('../lib/evaluate');
const { graphStats } = require('../lib/graph');

const DATASET = path.join(__dirname, '..', 'data', 'dataset.json');
const RAW = JSON.parse(fs.readFileSync(DATASET, 'utf8'));
const RR = RAW.r;
const SRC = RAW.m.sources, PUBS = RAW.m.publishers, COS = RAW.m.countries;
const JFILE = path.join(os.tmpdir(), `are-test-judgments-${process.pid}.json`);

let server, base;
const get = async (p) => { const r = await fetch(base + p); return { status: r.status, body: await r.json() }; };
const send = async (method, p, body) => {
  const r = await fetch(base + p, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json() };
};

test.before(async () => {
  try { fs.unlinkSync(JFILE); } catch { /* first run */ }
  server = createServer({ dataFile: DATASET, judgmentsFile: JFILE });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(async () => {
  await new Promise((resolve) => server.close(resolve));
  try { fs.unlinkSync(JFILE); } catch { /* nothing to clean */ }
});

// ---------------- API basics ----------------
test('health and meta', async () => {
  const h = await get('/api/health');
  assert.equal(h.body.ok, true);
  assert.equal(h.body.records, RR.length);
  const m = await get('/api/meta');
  assert.equal(m.body.recordCount, RR.length);
  assert.ok(m.body.facets.sources.length > 50);
});

test('search is paged and ranked by relevance', async () => {
  const { body } = await get('/api/search?q=library&pageSize=5');
  assert.ok(body.total > 100);
  assert.equal(body.results.length, 5);
  for (let i = 1; i < 5; i++) assert.ok(body.results[i - 1].score >= body.results[i].score);
});

test('record detail and 404', async () => {
  const ok = await get('/api/records/0');
  assert.equal(ok.status, 200);
  assert.ok(Array.isArray(ok.body.keywordList));
  assert.equal((await get('/api/records/999999999')).status, 404);
});

test('CSV export has header and neutralises formulas', async () => {
  const r = await fetch(base + '/api/export.csv?q=library&pageSize=3');
  assert.match(r.headers.get('content-type'), /text\/csv/);
  assert.ok((await r.text()).replace(/^\ufeff/, '').startsWith('id,title,authors'));
});

test('unknown endpoint, bad method and missing query give JSON errors', async () => {
  assert.equal((await get('/api/nope')).status, 404);
  assert.equal((await get('/api/dashboard/query')).status, 400);
  assert.equal((await send('DELETE', '/api/search', {})).status, 405);
});

test('path traversal outside public/ is refused', async () => {
  const status = await new Promise((resolve, reject) => {
    const u = new URL(base);
    http.get({ host: u.hostname, port: u.port, path: '/%2e%2e/%2e%2e/package.json' }, (res) => { res.resume(); resolve(res.statusCode); }).on('error', reject);
  });
  assert.notEqual(status, 200);
});

test('index page is served', async () => {
  const r = await fetch(base + '/');
  assert.equal(r.status, 200);
  assert.match(await r.text(), /Academic Research Explorer/);
});

// ---------------- Dashboard: overview figures against independent recomputation ----------------
test('overview: median, mean and totals match an independent calculation', async () => {
  const { body } = await get('/api/dashboard/overview?topN=10');
  const s = body.stats;
  const cit = RR.map((r) => r[0]).sort((a, b) => a - b);
  const median = RR.length % 2 ? cit[(RR.length - 1) / 2] : (cit[RR.length / 2 - 1] + cit[RR.length / 2]) / 2;
  assert.equal(s.n, RR.length);
  assert.equal(s.medianCitations, median);
  assert.ok(Math.abs(s.meanCitations - RR.reduce((a, r) => a + r[0], 0) / RR.length) < 1e-9);
});

test('overview: distinct keywords are case- and accent-insensitive', async () => {
  const set = new Set();
  RR.forEach((r) => String(r[11] || '').split(';').map((x) => x.trim()).filter(Boolean).forEach((k) => set.add(norm(k).trim())));
  const { body } = await get('/api/dashboard/overview');
  assert.equal(body.stats.distinct.keywords, set.size);
});

test('overview: missing journal count and top journal match an independent tally', async () => {
  const { body } = await get('/api/dashboard/overview?topN=3');
  const tally = new Map();
  let missing = 0;
  for (const r of RR) { if (!SRC[r[4]]) missing++; else tally.set(SRC[r[4]], (tally.get(SRC[r[4]]) || 0) + 1); }
  const top = [...tally].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0];
  assert.equal(body.stats.missing.journal, missing);
  assert.equal(body.stats.journals[0].name, top[0]);
  assert.equal(body.stats.journals[0].count, top[1]);
  assert.ok(Math.abs(body.stats.journals[0].share - top[1] / RR.length) < 1e-12);
});

test('overview: year range and keyword filter give exact counts', async () => {
  const y = await get('/api/dashboard/overview?from=2024&to=2024');
  assert.equal(y.body.stats.n, RR.filter((r) => r[3] === 2024).length);
  const k = await get('/api/dashboard/overview?filter=' + encodeURIComponent('keyword:COVID-19'));
  const expect = RR.filter((r) => String(r[11] || '').split(';').some((x) => norm(x).trim() === 'covid-19')).length;
  assert.equal(k.body.stats.n, expect);
});

test('overview: provenance states scope, filters and dataset size', async () => {
  const { body } = await get('/api/dashboard/overview?filter=' + encodeURIComponent('journal:Journal Of Big Data'));
  assert.equal(body.provenance.dataset.records, RR.length);
  assert.equal(body.provenance.filters[0].field, 'journal');
  assert.equal(body.provenance.recordsInBase, body.stats.n);
});

// ---------------- Query explorer ----------------
test('query explorer: matches equal the search total', async () => {
  const s = await get('/api/search?q=information%20literacy&pageSize=1');
  const d = await get('/api/dashboard/query?q=information%20literacy');
  assert.equal(d.body.query.matches, s.body.total);
});

test('query explorer: title matches and term enrichment match independent formulas', async () => {
  const s = await get('/api/search?q=information%20literacy&pageSize=1');
  const d = await get('/api/dashboard/query?q=information%20literacy');
  const hits = (await get('/api/search?q=information%20literacy&pageSize=100000')).body; // total only needed
  assert.equal(hits.total, s.body.total);
  const titleOK = RR.filter((r, i) => {
    const t = norm(r[2]);
    return t.includes('information') && t.includes('literacy') && (s.body.total >= 0);
  }).length;
  // every all-terms-in-title record must be among the matches; compare with a direct count over the collection
  const matchIds = new Set();
  let page = 1;
  while (matchIds.size < s.body.total) {
    const pg = (await get(`/api/search?q=information%20literacy&pageSize=100&page=${page++}`)).body;
    if (!pg.results.length) break;
    pg.results.forEach((x) => matchIds.add(x.id));
  }
  const inTitle = [...matchIds].filter((i) => { const t = norm(RR[i][2]); return t.includes('information') && t.includes('literacy'); }).length;
  assert.equal(d.body.query.allTermsInTitle, inTitle);
  assert.ok(titleOK >= inTitle);

  const lit = d.body.query.termStats.find((t) => t.term === 'literacy');
  const allText = (r) => norm(`${r[2]} ${r[1]} ${r[11]} ${SRC[r[4]] || ''} ${r[12]}`);
  const inM = [...matchIds].filter((i) => allText(RR[i]).includes('literacy')).length;
  const coll = RR.filter((r) => allText(r).includes('literacy')).length;
  assert.equal(lit.inMatches, inM);
  const expected = (inM / matchIds.size) / (coll / RR.length);
  assert.ok(Math.abs(lit.enrichment - expected) < 1e-9, `${lit.enrichment} vs ${expected}`);
});

test('query explorer: related keywords meet the minimum and exclude query terms', async () => {
  const d = await get('/api/dashboard/query?q=information%20literacy&minKw=5');
  d.body.query.related.forEach((r) => {
    assert.ok(r.count >= 5);
    assert.ok(!['information', 'literacy'].includes(r.key));
    assert.ok(Math.abs(r.lift - (r.count / d.body.query.matches) / (r.collection / RR.length)) < 1e-9);
  });
});

// ---------------- Knowledge graph ----------------
test('graph: nodes and edges are consistent and density follows its formula', async () => {
  const { body } = await get('/api/dashboard/graph?q=library&limit=20');
  const g = body.graph;
  assert.equal(body.provenance.recordsUsed, 20);
  assert.ok(g.nodes >= 20);
  assert.ok(g.components >= 1 && g.largestComponent <= g.nodes);
  assert.ok(Math.abs(g.density - (2 * g.edges) / (g.nodes * (g.nodes - 1))) < 1e-9);
  assert.ok(g.nodeTypes.some((t) => t.name === 'paper' && t.count === 20));
});

test('graph statistics: hand-checked components, density and isolated records', () => {
  const mk = (type, label, id) => ({ type, label, id });
  const P1 = mk('paper', 'P1', 0), P2 = mk('paper', 'P2', 1), P3 = mk('paper', 'P3', 2);
  const A = mk('author', 'A', 3), J = mk('journal', 'J', 4), K = mk('keyword', 'K', 5);
  const nodes = [P1, P2, P3, A, J, K];
  const edges = [[P1, A], [P1, J], [P2, A]].map(([a, b]) => ({ a, b, relation: 'x' }));
  const s = graphStats({ nodes, edges });
  assert.equal(s.nodes, 6);
  assert.equal(s.edges, 3);
  assert.equal(s.components, 3);          // {P1,A,J,P2}, {P3}, {K}
  assert.equal(s.largestComponent, 4);
  assert.ok(Math.abs(s.density - 6 / 30) < 1e-12);
  assert.equal(s.isolatedRecords, 1);      // P3 has no links
  assert.equal(s.maxLinks, 2);
});

// ---------------- Evaluation maths (hand-checked) ----------------
test('queryMetrics: precision, recall, nDCG and AP match hand calculation', () => {
  const ranking = [{ i: 10 }, { i: 11 }, { i: 12 }, { i: 13 }, { i: 14 }];
  const m = queryMetrics(ranking, { 10: 2, 11: 0, 12: 1, 13: 0, 99: 2 });
  assert.ok(Math.abs(m.precisionAt10 - 0.2) < 1e-12);
  assert.ok(Math.abs(m.recallAt10 - 2 / 3) < 1e-12);
  assert.ok(Math.abs(m.averagePrecision - (1 + 2 / 3) / 3) < 1e-12);
  const dcg = 2 / Math.log2(2) + 1 / Math.log2(4);
  const idcg = 2 / Math.log2(2) + 2 / Math.log2(3) + 1 / Math.log2(4);
  assert.ok(Math.abs(m.ndcgAt10 - dcg / idcg) < 1e-12);
  const none = queryMetrics(ranking, {});
  assert.equal(none.recallAt10, null);
  assert.equal(none.averagePrecision, null);
});

test('prCurve: average precision over two relevant results', () => {
  const ranking = [{ i: 10 }, { i: 11 }, { i: 12 }, { i: 13 }, { i: 14 }];
  const c = prCurve(ranking, { 10: 1, 12: 1 }, 5);
  assert.equal(c.relevantJudged, 2);
  assert.ok(Math.abs(c.averagePrecision - (1 + 2 / 3) / 2) < 1e-12);
  assert.ok(Math.abs(c.points[2].recall - 1) < 1e-12);
  assert.ok(Math.abs(c.points[2].precision - 2 / 3) < 1e-12);
});

test('rocAuc: pairwise probability, ties count half', () => {
  assert.ok(Math.abs(rocAuc([3, 5], [1, 4]) - 0.75) < 1e-12);
  assert.equal(rocAuc([2], [2]), 0.5);
  assert.equal(rocAuc([], [1]), null);
});

test("cohenKappa matches hand calculation (po = 3/4, pe = 7/16)", () => {
  const k = cohenKappa([[2, 2], [1, 1], [0, 2], [2, 2]]);
  assert.ok(Math.abs(k.agreement - 0.75) < 1e-12);
  assert.ok(Math.abs(k.kappa - (0.3125 / 0.5625)) < 1e-12);
  assert.equal(cohenKappa([]).kappa, null);
});

test('heuristicGrade: 2 for all terms in title, 1 for half in keywords or abstract, 0 otherwise', () => {
  const rec = (t, k, b) => ({ n: { t: norm(t), k: norm(k), b: norm(b) } });
  assert.equal(heuristicGrade(rec('Information literacy in schools', '', ''), 'information literacy').g, 2);
  assert.equal(heuristicGrade(rec('Digital tools', 'literacy', 'information'), 'information literacy').g, 1);
  assert.equal(heuristicGrade(rec('Soil chemistry', 'minerals', 'rocks'), 'information literacy').g, 0);
});

// ---------------- Judgments and evaluation endpoints (end to end) ----------------
test('judgments: validation rejects bad input', async () => {
  assert.equal((await send('POST', '/api/judgments', { q: '', id: 1, grade: 1 })).status, 400);
  assert.equal((await send('POST', '/api/judgments', { q: 'x', id: -1, grade: 1 })).status, 400);
  assert.equal((await send('POST', '/api/judgments', { q: 'x', id: 1, grade: 7 })).status, 400);
  assert.equal((await send('POST', '/api/judgments', { q: 'x', id: 1 })).status, 400);
});

test('judgments: save, read back, clear, and persist to disk', async () => {
  assert.equal((await send('POST', '/api/judgments', { q: 'information literacy', id: 3, grade: 2 })).status, 200);
  const got = await get('/api/judgments?q=' + encodeURIComponent('information literacy'));
  assert.equal(got.body.grades['3'], 2);
  assert.ok(JSON.parse(fs.readFileSync(JFILE, 'utf8'))['information literacy']);
  await send('POST', '/api/judgments', { q: 'information literacy', id: 3, grade: null });
  const cleared = await get('/api/judgments?q=' + encodeURIComponent('information literacy'));
  assert.deepEqual(cleared.body.grades, {});
});

test('batch, curve and heuristic reflect judged results end to end', async () => {
  const q = 'information literacy';
  const top = (await get('/api/search?q=' + encodeURIComponent(q) + '&pageSize=5')).body.results;
  // judge the top five: the first two as relevant, the rest as not relevant
  for (let k = 0; k < 5; k++) await send('POST', '/api/judgments', { q, id: top[k].id, grade: k < 2 ? 2 : 0 });

  const batch = (await get('/api/evaluate/batch')).body;
  const row = batch.queries.find((r) => r.query === q);
  assert.ok(row);
  assert.equal(row.relevantJudged, 2);
  assert.ok(Math.abs(row.precisionAt10 - 0.2) < 1e-12);  // 2 relevant in the top 10, but only 2 of 10 slots
  assert.ok(Math.abs(row.recallAt10 - 1) < 1e-12);       // both judged-relevant results are in the top 10

  const curve = (await get('/api/evaluate/curve?q=' + encodeURIComponent(q))).body;
  assert.equal(curve.relevantJudged, 2);
  assert.ok(curve.averagePrecision > 0 && curve.averagePrecision <= 1);

  const heur = (await get('/api/evaluate/heuristic?q=' + encodeURIComponent(q) + '&depth=5')).body;
  assert.equal(heur.rows.length, 5);
  assert.ok(heur.rows.every((r) => [0, 1, 2].includes(r.auto)));
  assert.equal(heur.agreement.n, 5);

  const acc = await send('POST', '/api/evaluate/heuristic/accept', { q, depth: 10 });
  assert.equal(acc.status, 200);
  assert.equal(acc.body.added, 5);                        // results 6..10 were unjudged
  assert.equal(Object.keys(acc.body.grades).length, 10);
  // accepting again adds nothing: suggestions never overwrite human judgments
  assert.equal((await send('POST', '/api/evaluate/heuristic/accept', { q, depth: 10 })).body.added, 0);
  assert.equal(acc.body.grades[String(top[0].id)], 2);
});

test('export summary bundles provenance, overview, query and graph', async () => {
  const r = await fetch(base + '/api/export/summary?q=information%20literacy&topN=5&limit=10');
  assert.match(r.headers.get('content-disposition'), /dashboard-summary\.json/);
  const j = await r.json();
  assert.equal(j.provenance.dataset.records, RR.length);
  assert.ok(j.overview.n === RR.length);
  assert.ok(j.queryExplorer.matches > 0);
  assert.ok(j.knowledgeGraph.nodes > 0);
});

test('CORS: API answers browsers on other origins, including file:// pages', async () => {
  const r = await fetch(base + '/api/meta', { headers: { Origin: 'null' } });
  assert.equal(r.headers.get('access-control-allow-origin'), '*');
  const pre = await fetch(base + '/api/judgments', { method: 'OPTIONS', headers: { Origin: 'null', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type' } });
  assert.equal(pre.status, 204);
  assert.match(pre.headers.get('access-control-allow-methods'), /POST/);
  assert.match(pre.headers.get('access-control-allow-headers'), /Content-Type/i);
});
