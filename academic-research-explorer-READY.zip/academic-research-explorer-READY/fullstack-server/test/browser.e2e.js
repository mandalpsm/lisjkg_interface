'use strict';
/**
 * Optional browser test. Needs Playwright and a Chromium build:
 *   npm i -D playwright && npx playwright install chromium
 * Skips itself when Playwright is not installed, so `npm test` stays dependency-free.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const { createServer } = require('../server');

let pw = null;
try { pw = require('playwright'); } catch { pw = null; }
const skip = pw ? false : 'playwright not installed (optional)';

test('browser: search, dashboard filters, query explorer, graph, grading and metrics', { skip }, async (t) => {
  const jfile = path.join(os.tmpdir(), `are-e2e-${process.pid}.json`);
  const server = createServer({ dataFile: path.join(__dirname, '..', 'data', 'dataset.json'), judgmentsFile: jfile });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}/`;
  let browser;
  try {
    browser = await pw.chromium.launch();
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    await page.goto(base);
    await page.waitForSelector('#results article', { timeout: 20000 });

    await page.fill('#q', 'information literacy');
    await page.click('#qform button');
    await page.waitForFunction(() => /for “information literacy”/.test(document.querySelector('#resCount').textContent), null, { timeout: 20000 });

    await page.click('#t-dash');
    await page.waitForSelector('#dPanel .kpis', { timeout: 30000 });
    await page.click('#dPanel button.dbar[data-f="journal"]');
    await page.waitForFunction(() => document.querySelectorAll('#dChips .chip').length === 1);
    await page.waitForFunction(() => !/27,825/.test(document.querySelector('#dbStatus').textContent), null, { timeout: 20000 });
    await page.click('#dChips [data-rm="0"]');

    await page.click('.sub button[data-sub="query"]');
    await page.waitForFunction(() => /Share of collection/.test(document.querySelector('#dPanel').textContent), null, { timeout: 30000 });
    await page.click('.sub button[data-sub="graph"]');
    await page.waitForSelector('#dPanel svg[role="img"]', { timeout: 30000 });

    await page.click('#t-eval');
    await page.fill('#eQ', 'information literacy');
    await page.click('#eLoad');
    await page.waitForSelector('#eJudge select[data-grade]', { timeout: 20000 });
    await page.locator('#eJudge select[data-grade]').nth(0).selectOption('2');
    await page.waitForTimeout(300);
    await page.locator('#eJudge select[data-grade]').nth(1).selectOption('1');
    await page.waitForFunction(() => /Precision@10/.test(document.querySelector('#eMetrics').textContent), null, { timeout: 20000 });
    await page.waitForSelector('#eCurve svg', { timeout: 20000 });

    assert.deepEqual(errors, [], 'no page errors or console errors');
  } finally {
    if (browser) await browser.close();
    await new Promise((r) => server.close(r));
    try { fs.unlinkSync(jfile); } catch { /* nothing written */ }
  }
});

test('browser: the page opened from disk (file://) reads the API given by ?api=', { skip }, async () => {
  const jfile = path.join(os.tmpdir(), `are-e2e-file-${process.pid}.json`);
  const server = createServer({ dataFile: path.join(__dirname, '..', 'data', 'dataset.json'), judgmentsFile: jfile });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const api = `http://127.0.0.1:${server.address().port}`;
  const file = 'file://' + path.join(__dirname, '..', 'public', 'index.html') + '?api=' + encodeURIComponent(api);
  let browser;
  try {
    browser = await pw.chromium.launch();
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto(file);
    await page.waitForSelector('#results article', { timeout: 30000 });
    assert.deepEqual(errors, []);
  } finally {
    if (browser) await browser.close();
    await new Promise((r) => server.close(r));
    try { fs.unlinkSync(jfile); } catch { /* nothing written */ }
  }
});

test('browser: opened from disk with no server, the page explains what to do', { skip }, async () => {
  let browser;
  try {
    browser = await pw.chromium.launch();
    const page = await browser.newPage();
    // Port 9 is reserved and never serves HTTP here, so the page reports the service as unreachable.
    await page.goto('file://' + path.join(__dirname, '..', 'public', 'index.html') + '?api=' + encodeURIComponent('http://127.0.0.1:9'));
    await page.waitForSelector('#retryInit', { timeout: 30000 });
    assert.match(await page.textContent('#results'), /npm start/);
  } finally {
    if (browser) await browser.close();
  }
});
